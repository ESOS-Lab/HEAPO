void clflush(volatile void *__p) ;
